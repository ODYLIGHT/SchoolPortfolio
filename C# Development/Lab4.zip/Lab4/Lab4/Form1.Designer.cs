﻿namespace Lab4
{
    partial class Lab4form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGPA = new System.Windows.Forms.Label();
            this.lblTestScore = new System.Windows.Forms.Label();
            this.textBoxGPA = new System.Windows.Forms.TextBox();
            this.textBoxTestScore = new System.Windows.Forms.TextBox();
            this.OutputLblAcceptance = new System.Windows.Forms.Label();
            this.btnAcceptance = new System.Windows.Forms.Button();
            this.labelFinaldec = new System.Windows.Forms.Label();
            this.labelacceptedtotal = new System.Windows.Forms.Label();
            this.outputlabelaccepted = new System.Windows.Forms.Label();
            this.labelrejectedtotal = new System.Windows.Forms.Label();
            this.outputlabelrejected = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblGPA
            // 
            this.lblGPA.AutoSize = true;
            this.lblGPA.Location = new System.Drawing.Point(130, 29);
            this.lblGPA.Name = "lblGPA";
            this.lblGPA.Size = new System.Drawing.Size(32, 13);
            this.lblGPA.TabIndex = 0;
            this.lblGPA.Text = "GPA:";
            // 
            // lblTestScore
            // 
            this.lblTestScore.AutoSize = true;
            this.lblTestScore.Location = new System.Drawing.Point(50, 69);
            this.lblTestScore.Name = "lblTestScore";
            this.lblTestScore.Size = new System.Drawing.Size(112, 13);
            this.lblTestScore.TabIndex = 1;
            this.lblTestScore.Text = "Admission Test Score:";
            // 
            // textBoxGPA
            // 
            this.textBoxGPA.Location = new System.Drawing.Point(180, 26);
            this.textBoxGPA.Name = "textBoxGPA";
            this.textBoxGPA.Size = new System.Drawing.Size(100, 20);
            this.textBoxGPA.TabIndex = 2;
            // 
            // textBoxTestScore
            // 
            this.textBoxTestScore.Location = new System.Drawing.Point(180, 66);
            this.textBoxTestScore.Name = "textBoxTestScore";
            this.textBoxTestScore.Size = new System.Drawing.Size(100, 20);
            this.textBoxTestScore.TabIndex = 3;
            // 
            // OutputLblAcceptance
            // 
            this.OutputLblAcceptance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputLblAcceptance.Location = new System.Drawing.Point(180, 108);
            this.OutputLblAcceptance.Name = "OutputLblAcceptance";
            this.OutputLblAcceptance.Size = new System.Drawing.Size(100, 23);
            this.OutputLblAcceptance.TabIndex = 4;
            // 
            // btnAcceptance
            // 
            this.btnAcceptance.AutoSize = true;
            this.btnAcceptance.Location = new System.Drawing.Point(75, 152);
            this.btnAcceptance.Name = "btnAcceptance";
            this.btnAcceptance.Size = new System.Drawing.Size(142, 23);
            this.btnAcceptance.TabIndex = 5;
            this.btnAcceptance.Text = "Check Admission Decision";
            this.btnAcceptance.UseVisualStyleBackColor = true;
            this.btnAcceptance.Click += new System.EventHandler(this.btnAcceptance_Click);
            // 
            // labelFinaldec
            // 
            this.labelFinaldec.AutoSize = true;
            this.labelFinaldec.Location = new System.Drawing.Point(111, 109);
            this.labelFinaldec.Name = "labelFinaldec";
            this.labelFinaldec.Size = new System.Drawing.Size(51, 13);
            this.labelFinaldec.TabIndex = 6;
            this.labelFinaldec.Text = "Decision:";
            // 
            // labelacceptedtotal
            // 
            this.labelacceptedtotal.AutoSize = true;
            this.labelacceptedtotal.Location = new System.Drawing.Point(79, 198);
            this.labelacceptedtotal.Name = "labelacceptedtotal";
            this.labelacceptedtotal.Size = new System.Drawing.Size(83, 13);
            this.labelacceptedtotal.TabIndex = 7;
            this.labelacceptedtotal.Text = "Accepted Total:";
            // 
            // outputlabelaccepted
            // 
            this.outputlabelaccepted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelaccepted.Location = new System.Drawing.Point(177, 197);
            this.outputlabelaccepted.Name = "outputlabelaccepted";
            this.outputlabelaccepted.Size = new System.Drawing.Size(100, 23);
            this.outputlabelaccepted.TabIndex = 8;
            // 
            // labelrejectedtotal
            // 
            this.labelrejectedtotal.AutoSize = true;
            this.labelrejectedtotal.Location = new System.Drawing.Point(82, 241);
            this.labelrejectedtotal.Name = "labelrejectedtotal";
            this.labelrejectedtotal.Size = new System.Drawing.Size(80, 13);
            this.labelrejectedtotal.TabIndex = 9;
            this.labelrejectedtotal.Text = "Rejected Total:";
            // 
            // outputlabelrejected
            // 
            this.outputlabelrejected.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelrejected.Location = new System.Drawing.Point(177, 240);
            this.outputlabelrejected.Name = "outputlabelrejected";
            this.outputlabelrejected.Size = new System.Drawing.Size(100, 23);
            this.outputlabelrejected.TabIndex = 10;
            // 
            // Lab4form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.outputlabelrejected);
            this.Controls.Add(this.labelrejectedtotal);
            this.Controls.Add(this.outputlabelaccepted);
            this.Controls.Add(this.labelacceptedtotal);
            this.Controls.Add(this.labelFinaldec);
            this.Controls.Add(this.btnAcceptance);
            this.Controls.Add(this.OutputLblAcceptance);
            this.Controls.Add(this.textBoxTestScore);
            this.Controls.Add(this.textBoxGPA);
            this.Controls.Add(this.lblTestScore);
            this.Controls.Add(this.lblGPA);
            this.Name = "Lab4form";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGPA;
        private System.Windows.Forms.Label lblTestScore;
        private System.Windows.Forms.TextBox textBoxGPA;
        private System.Windows.Forms.TextBox textBoxTestScore;
        private System.Windows.Forms.Label OutputLblAcceptance;
        private System.Windows.Forms.Button btnAcceptance;
        private System.Windows.Forms.Label labelFinaldec;
        private System.Windows.Forms.Label labelacceptedtotal;
        private System.Windows.Forms.Label outputlabelaccepted;
        private System.Windows.Forms.Label labelrejectedtotal;
        private System.Windows.Forms.Label outputlabelrejected;
    }
}

