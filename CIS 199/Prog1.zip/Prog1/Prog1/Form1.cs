﻿//By: Dylan Thomas
//2-14-2016
//CIS 199-01
//Program 1
/* This application was created to determine the total cost of painting a room. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog1
{
    public partial class ProgramForm : Form
    {
        public ProgramForm()
        {
            InitializeComponent();
        }

        private void buttontotalcost_Click(object sender, EventArgs e)
        {
            try
            {
                double SQUAREFEET;  //To hold the square feet of wall space.
                int NUMBEROFCOATS;  //To hold the number of coats of paints desired.
                double PRICEOFPAINTPERGAL;  //To hold the price of the paint per gallon.
                double TOTALSQUAREFEET; //Total square feet to be painted.
                int GALLONSOFPAINT; //The number of gallons of paint required.
                double HOURSOFLABOR;    //The hours of labor required.
                double COSTOFPAINT; //The cost of the paint.
                double COSTOFLABOR; //The cost of the labor.
                double TOTALCOST;   //The total cost of the paint job.
                const double SQUAREFEETPERGAL = 325;    //The square feet per gallon.
                const double HOURSOFLABORPERGAL = 8;    //The hours of labor required per gallon of paint.
                const double PAYPERHOUR = 10.5; //The price per hour for labor.

                SQUAREFEET = double.Parse(textBoxSquarefeet.Text);  //To assign the square feet to the SQUARE FEET variable.
                NUMBEROFCOATS = int.Parse(textBoxCoatsofPaint.Text);    //To assign the number of coats of paint to the NUMBEROFCOATS variable.
                PRICEOFPAINTPERGAL = double.Parse(textBoxpaintpergal.Text); //To assign the price of paint per gallon to the PRICEOFPAINTPERGAL variable.

                TOTALSQUAREFEET = SQUAREFEET * NUMBEROFCOATS;   //Calculate the total square feet.

                outputlabelTotalsquarefeet.Text = TOTALSQUAREFEET.ToString("n1");   //Display the total square feet in the outputlabelTotalsquarefeet control.

                GALLONSOFPAINT = (int)Math.Ceiling(TOTALSQUAREFEET / SQUAREFEETPERGAL); //Calculate the total gallons of paint needed.

                outputlabeltotalgalpaint.Text = GALLONSOFPAINT.ToString();  //Display the total gallons of paint in the outputlabeltotalgalpaint control.

                HOURSOFLABOR = TOTALSQUAREFEET / SQUAREFEETPERGAL * HOURSOFLABORPERGAL; //Calculate the total hours of labor.

                outputlabelHoursoflabor.Text = HOURSOFLABOR.ToString("n1"); //Display the total hours of labor in the outputlabelHoursoflabor control.

                COSTOFPAINT = GALLONSOFPAINT * PRICEOFPAINTPERGAL;  //Calculate the total cost of paint.

                outputlabelcostofpaint.Text = COSTOFPAINT.ToString("c");    //Display the total cost of paint in the outputlabelcostofpaint control.

                COSTOFLABOR = HOURSOFLABOR * PAYPERHOUR;    //Calculate the cost of labor.

                outputlabelCostoflabor.Text = COSTOFLABOR.ToString("c");    //Display the cost of labor in the outputlabelCostoflabor control.

                TOTALCOST = COSTOFPAINT + COSTOFLABOR;  //Calculate the total cost of the paint job.

                outputlabeltotalcost.Text = TOTALCOST.ToString("c");    //Display the total cost of the paint job in the outputlabeltotalcost control.
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    //Display the default error message.
            }
        }
    }
}
