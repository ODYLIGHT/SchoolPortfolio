﻿namespace Prog1
{
    partial class ProgramForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelSquarefeet = new System.Windows.Forms.Label();
            this.textBoxSquarefeet = new System.Windows.Forms.TextBox();
            this.labelCoatsofPaint = new System.Windows.Forms.Label();
            this.textBoxCoatsofPaint = new System.Windows.Forms.TextBox();
            this.labelPaintcostpergal = new System.Windows.Forms.Label();
            this.textBoxpaintpergal = new System.Windows.Forms.TextBox();
            this.labelTotalsquarefeet = new System.Windows.Forms.Label();
            this.outputlabelTotalsquarefeet = new System.Windows.Forms.Label();
            this.labeltotalgallons = new System.Windows.Forms.Label();
            this.outputlabeltotalgalpaint = new System.Windows.Forms.Label();
            this.labelhoursoflabor = new System.Windows.Forms.Label();
            this.outputlabelHoursoflabor = new System.Windows.Forms.Label();
            this.labelCostofpaint = new System.Windows.Forms.Label();
            this.outputlabelcostofpaint = new System.Windows.Forms.Label();
            this.labelcostoflabor = new System.Windows.Forms.Label();
            this.outputlabelCostoflabor = new System.Windows.Forms.Label();
            this.labeltotalcost = new System.Windows.Forms.Label();
            this.outputlabeltotalcost = new System.Windows.Forms.Label();
            this.buttontotalcost = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelSquarefeet
            // 
            this.labelSquarefeet.AutoSize = true;
            this.labelSquarefeet.Location = new System.Drawing.Point(31, 23);
            this.labelSquarefeet.Name = "labelSquarefeet";
            this.labelSquarefeet.Size = new System.Drawing.Size(130, 13);
            this.labelSquarefeet.TabIndex = 0;
            this.labelSquarefeet.Text = "Square feet of wall space:";
            // 
            // textBoxSquarefeet
            // 
            this.textBoxSquarefeet.Location = new System.Drawing.Point(180, 20);
            this.textBoxSquarefeet.Name = "textBoxSquarefeet";
            this.textBoxSquarefeet.Size = new System.Drawing.Size(100, 20);
            this.textBoxSquarefeet.TabIndex = 1;
            // 
            // labelCoatsofPaint
            // 
            this.labelCoatsofPaint.AutoSize = true;
            this.labelCoatsofPaint.Location = new System.Drawing.Point(86, 62);
            this.labelCoatsofPaint.Name = "labelCoatsofPaint";
            this.labelCoatsofPaint.Size = new System.Drawing.Size(75, 13);
            this.labelCoatsofPaint.TabIndex = 2;
            this.labelCoatsofPaint.Text = "Coats of paint:";
            // 
            // textBoxCoatsofPaint
            // 
            this.textBoxCoatsofPaint.Location = new System.Drawing.Point(180, 59);
            this.textBoxCoatsofPaint.Name = "textBoxCoatsofPaint";
            this.textBoxCoatsofPaint.Size = new System.Drawing.Size(100, 20);
            this.textBoxCoatsofPaint.TabIndex = 3;
            // 
            // labelPaintcostpergal
            // 
            this.labelPaintcostpergal.AutoSize = true;
            this.labelPaintcostpergal.Location = new System.Drawing.Point(43, 101);
            this.labelPaintcostpergal.Name = "labelPaintcostpergal";
            this.labelPaintcostpergal.Size = new System.Drawing.Size(118, 13);
            this.labelPaintcostpergal.TabIndex = 4;
            this.labelPaintcostpergal.Text = "Cost of paint per gallon:";
            // 
            // textBoxpaintpergal
            // 
            this.textBoxpaintpergal.Location = new System.Drawing.Point(180, 98);
            this.textBoxpaintpergal.Name = "textBoxpaintpergal";
            this.textBoxpaintpergal.Size = new System.Drawing.Size(100, 20);
            this.textBoxpaintpergal.TabIndex = 5;
            // 
            // labelTotalsquarefeet
            // 
            this.labelTotalsquarefeet.AutoSize = true;
            this.labelTotalsquarefeet.Location = new System.Drawing.Point(71, 140);
            this.labelTotalsquarefeet.Name = "labelTotalsquarefeet";
            this.labelTotalsquarefeet.Size = new System.Drawing.Size(90, 13);
            this.labelTotalsquarefeet.TabIndex = 6;
            this.labelTotalsquarefeet.Text = "Total square feet:";
            // 
            // outputlabelTotalsquarefeet
            // 
            this.outputlabelTotalsquarefeet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelTotalsquarefeet.Location = new System.Drawing.Point(180, 139);
            this.outputlabelTotalsquarefeet.Name = "outputlabelTotalsquarefeet";
            this.outputlabelTotalsquarefeet.Size = new System.Drawing.Size(100, 23);
            this.outputlabelTotalsquarefeet.TabIndex = 7;
            // 
            // labeltotalgallons
            // 
            this.labeltotalgallons.AutoSize = true;
            this.labeltotalgallons.Location = new System.Drawing.Point(53, 179);
            this.labeltotalgallons.Name = "labeltotalgallons";
            this.labeltotalgallons.Size = new System.Drawing.Size(108, 13);
            this.labeltotalgallons.TabIndex = 8;
            this.labeltotalgallons.Text = "Total gallons of paint:";
            // 
            // outputlabeltotalgalpaint
            // 
            this.outputlabeltotalgalpaint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabeltotalgalpaint.Location = new System.Drawing.Point(180, 178);
            this.outputlabeltotalgalpaint.Name = "outputlabeltotalgalpaint";
            this.outputlabeltotalgalpaint.Size = new System.Drawing.Size(100, 23);
            this.outputlabeltotalgalpaint.TabIndex = 9;
            // 
            // labelhoursoflabor
            // 
            this.labelhoursoflabor.AutoSize = true;
            this.labelhoursoflabor.Location = new System.Drawing.Point(44, 218);
            this.labelhoursoflabor.Name = "labelhoursoflabor";
            this.labelhoursoflabor.Size = new System.Drawing.Size(117, 13);
            this.labelhoursoflabor.TabIndex = 10;
            this.labelhoursoflabor.Text = "Hours of labor required:";
            // 
            // outputlabelHoursoflabor
            // 
            this.outputlabelHoursoflabor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelHoursoflabor.Location = new System.Drawing.Point(180, 217);
            this.outputlabelHoursoflabor.Name = "outputlabelHoursoflabor";
            this.outputlabelHoursoflabor.Size = new System.Drawing.Size(100, 23);
            this.outputlabelHoursoflabor.TabIndex = 11;
            // 
            // labelCostofpaint
            // 
            this.labelCostofpaint.AutoSize = true;
            this.labelCostofpaint.Location = new System.Drawing.Point(92, 256);
            this.labelCostofpaint.Name = "labelCostofpaint";
            this.labelCostofpaint.Size = new System.Drawing.Size(69, 13);
            this.labelCostofpaint.TabIndex = 12;
            this.labelCostofpaint.Text = "Cost of paint:";
            // 
            // outputlabelcostofpaint
            // 
            this.outputlabelcostofpaint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelcostofpaint.Location = new System.Drawing.Point(180, 256);
            this.outputlabelcostofpaint.Name = "outputlabelcostofpaint";
            this.outputlabelcostofpaint.Size = new System.Drawing.Size(100, 23);
            this.outputlabelcostofpaint.TabIndex = 13;
            // 
            // labelcostoflabor
            // 
            this.labelcostoflabor.AutoSize = true;
            this.labelcostoflabor.Location = new System.Drawing.Point(92, 295);
            this.labelcostoflabor.Name = "labelcostoflabor";
            this.labelcostoflabor.Size = new System.Drawing.Size(69, 13);
            this.labelcostoflabor.TabIndex = 14;
            this.labelcostoflabor.Text = "Cost of labor:";
            // 
            // outputlabelCostoflabor
            // 
            this.outputlabelCostoflabor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelCostoflabor.Location = new System.Drawing.Point(180, 295);
            this.outputlabelCostoflabor.Name = "outputlabelCostoflabor";
            this.outputlabelCostoflabor.Size = new System.Drawing.Size(100, 23);
            this.outputlabelCostoflabor.TabIndex = 15;
            // 
            // labeltotalcost
            // 
            this.labeltotalcost.AutoSize = true;
            this.labeltotalcost.Location = new System.Drawing.Point(104, 335);
            this.labeltotalcost.Name = "labeltotalcost";
            this.labeltotalcost.Size = new System.Drawing.Size(57, 13);
            this.labeltotalcost.TabIndex = 16;
            this.labeltotalcost.Text = "Total cost:";
            // 
            // outputlabeltotalcost
            // 
            this.outputlabeltotalcost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabeltotalcost.Location = new System.Drawing.Point(180, 334);
            this.outputlabeltotalcost.Name = "outputlabeltotalcost";
            this.outputlabeltotalcost.Size = new System.Drawing.Size(100, 23);
            this.outputlabeltotalcost.TabIndex = 17;
            // 
            // buttontotalcost
            // 
            this.buttontotalcost.Location = new System.Drawing.Point(109, 386);
            this.buttontotalcost.Name = "buttontotalcost";
            this.buttontotalcost.Size = new System.Drawing.Size(75, 23);
            this.buttontotalcost.TabIndex = 18;
            this.buttontotalcost.Text = "Total cost";
            this.buttontotalcost.UseVisualStyleBackColor = true;
            this.buttontotalcost.Click += new System.EventHandler(this.buttontotalcost_Click);
            // 
            // ProgramForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 421);
            this.Controls.Add(this.buttontotalcost);
            this.Controls.Add(this.outputlabeltotalcost);
            this.Controls.Add(this.labeltotalcost);
            this.Controls.Add(this.outputlabelCostoflabor);
            this.Controls.Add(this.labelcostoflabor);
            this.Controls.Add(this.outputlabelcostofpaint);
            this.Controls.Add(this.labelCostofpaint);
            this.Controls.Add(this.outputlabelHoursoflabor);
            this.Controls.Add(this.labelhoursoflabor);
            this.Controls.Add(this.outputlabeltotalgalpaint);
            this.Controls.Add(this.labeltotalgallons);
            this.Controls.Add(this.outputlabelTotalsquarefeet);
            this.Controls.Add(this.labelTotalsquarefeet);
            this.Controls.Add(this.textBoxpaintpergal);
            this.Controls.Add(this.labelPaintcostpergal);
            this.Controls.Add(this.textBoxCoatsofPaint);
            this.Controls.Add(this.labelCoatsofPaint);
            this.Controls.Add(this.textBoxSquarefeet);
            this.Controls.Add(this.labelSquarefeet);
            this.Name = "ProgramForm";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelSquarefeet;
        private System.Windows.Forms.TextBox textBoxSquarefeet;
        private System.Windows.Forms.Label labelCoatsofPaint;
        private System.Windows.Forms.TextBox textBoxCoatsofPaint;
        private System.Windows.Forms.Label labelPaintcostpergal;
        private System.Windows.Forms.TextBox textBoxpaintpergal;
        private System.Windows.Forms.Label labelTotalsquarefeet;
        private System.Windows.Forms.Label outputlabelTotalsquarefeet;
        private System.Windows.Forms.Label labeltotalgallons;
        private System.Windows.Forms.Label outputlabeltotalgalpaint;
        private System.Windows.Forms.Label labelhoursoflabor;
        private System.Windows.Forms.Label outputlabelHoursoflabor;
        private System.Windows.Forms.Label labelCostofpaint;
        private System.Windows.Forms.Label outputlabelcostofpaint;
        private System.Windows.Forms.Label labelcostoflabor;
        private System.Windows.Forms.Label outputlabelCostoflabor;
        private System.Windows.Forms.Label labeltotalcost;
        private System.Windows.Forms.Label outputlabeltotalcost;
        private System.Windows.Forms.Button buttontotalcost;
    }
}

