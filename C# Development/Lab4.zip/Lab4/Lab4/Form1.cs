﻿//By: Dylan Thomas
//Lab4
//CIS199-01
//2-16-2016
/*This application was created to determine if a student was accepted or rejected into a university based on their gpa and admission scores. 
 * The application also keeps a running total of how many students are accepted or rejected by the university.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Lab4form : Form
    {
        private int acceptedTotal = 0;  //This field variable holds the total number of accepted students.
        private int rejectedTotal = 0;  //This field variable holds the total number of rejected students.
        public Lab4form()
        {
            InitializeComponent();
        }

        private void btnAcceptance_Click(object sender, EventArgs e)
        {
            const decimal MINIMUM_GPA = 3.0m;   //This constant contains the minimum GPA required to get accepted.
            const int MINIMUM_TESTSCORE = 60;   //This constant contains the minimum testscore required to be accepted.
            const int LONE_TESTSCORE = 80;  //This constant contains the testscore that will get you accepted regardless of you GPA.
            decimal gpa;    //This variable holds the students GPA.
            int testscore;  //This variable holds the students testscore.

            //Get the student's GPA and testscore.
            gpa = decimal.Parse(textBoxGPA.Text);
            testscore = int.Parse(textBoxTestScore.Text);

            //Determines if the student meets the minimum GPA and testscore required to get accepted and adds 1 to the accepted total if requirments are met.
            if (gpa >= MINIMUM_GPA && testscore >= MINIMUM_TESTSCORE)
            {
                acceptedTotal += 1;
                OutputLblAcceptance.Text = "Accept";
                outputlabelaccepted.Text = acceptedTotal.ToString();
            }
            //Determines if the student meets the testscore that will alone accept him or her. Also will add 1 to the accepted total if requirments are met.
            else if (testscore >= LONE_TESTSCORE)
            {
                acceptedTotal += 1;
                OutputLblAcceptance.Text = "Accept";
                outputlabelaccepted.Text = acceptedTotal.ToString();
            }
            //Rejects student for not meeting requirments and adds 1 to the rejected total.
            else
            {
                rejectedTotal += 1;
                OutputLblAcceptance.Text = "Reject";
                outputlabelrejected.Text = rejectedTotal.ToString();
            }

        }
    }
}
